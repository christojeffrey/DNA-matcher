package main

var databaseReference = "root@tcp(localhost:3306)/"
